//_______________ BASE DE DADOS ____________

let alunos =[
  {
    num: 1,
    nome: "David",
    distrito: "Castelo Branco",
    genero:"Masculino",
    morada:"Edificio Beira Bloco",
    data: "2001-01-01",
    email: "david@gmail.com",
    curso: "Curso de Pastelaria"
  },
  {
    num: 2,
    nome: "Nuno",
    distrito: "Castelo Branco",
    genero:"Masculino",
    morada:"Canhoso",
    data: "2001-03-01",
    email: "nuno@gmail.com",
    curso: "Curso de Zero Desperdicio"
  }
  ,
  {
    num: 3,
    nome: "Alexandre",
    distrito: "Porto",
    genero:"Masculino",
    morada:"Porto",
    data: "2001-09-03",
    email: "alexandre@gmail.com",
    curso: "Curso Cozinha Delicada"
  }
  ,
  {
    num: 4,
    nome: "Miguel",
    distrito: "Castelo Branco",
    genero:"Masculino",
    morada:"Capinha",
    data: "2001-11-01",
    email: "miguel@gmail.com",
    curso: "Curso Técnicas de Cozinha"
  }
  ,
  {
    num: 5,
    nome: "Bruna",
    distrito: "Castelo Branco",
    genero:"Feminino",
    morada:"Fundão",
    data: "2001-05-23",
    email: "bruna@gmail.com",
    curso: "Curso Gastronomia Regional"
  },
  {
    num: 6,
    nome: "Karina",
    distrito: "Lisboa",
    genero:"Feminino",
    morada:"Lisboa",
    data: "2003-05-23",
    email: "karina@gmail.com",
    curso: "Curso Gastronomia Regional"
  },  
  {
    num: 7,
    nome: "Ana Monteiro",
    distrito: "Porto",
    genero:"Feminino",
    morada:"Fundão",
    data: "2000-05-23",
    email: "ana@gmail.com",
    curso: "Curso Gastronomia Regional"
  }
]
//____________________________________________

const express = require('express')
const app = express()
const port = 3000

app.use(express.json());
app.use(express.urlencoded());

app.use(express.static('public'))


app.get("/mostrarAlunos",(req,res) =>{

  res.send(alunos);

});

app.put("/editarAluno/:id", (req,res) =>{

  const id = req.params.id;
  changeDesc(id);

  function changeDesc(id) {
    for (var i in alunos) {
      if (alunos[i].num == id) {
         alunos[i].num =  parseInt(req.body.num);
         alunos[i].nome =  req.body.nome;
         alunos[i].distrito = req.body.distrito;
         alunos[i].genero = req.body.genero;
         alunos[i].morada = req.body.morada;
         alunos[i].data = req.body.data;
         alunos[i].email = req.body.email;
         alunos[i].curso = req.body.curso;
         break; 
      }
    }
 }
  res.send("Editado com sucesso");

});
  
app.delete("/apagarAluno/:id",(req,res) =>{
  // req.params.id é o valor que recebe pelo url que foi enviado pelo ajax
  const id = req.params.id;
  
  // procura dentro do array 
  const pos = alunos.map(alunos => alunos.num).indexOf(parseInt(id));
  alunos.splice(pos, 1);
  res.send("Apagado com sucesso")
});

app.post('/criarAluno',(req,res)=>{

  let size = alunos.length + 1;

  data={
    num: size,
    nome: req.body.nome,
    distrito: req.body.distrito,
    genero: req.body.genero,
    morada: req.body.morada,
    data: req.body.data,
    email: req.body.email,
    curso: req.body.curso
  }
  alunos.push(data);
  res.send("Inscrição concluída com sucesso");

});


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
