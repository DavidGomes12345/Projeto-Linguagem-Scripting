class Aluno {
    constructor(nome,distrito, genero, morada, data, email, curso) {
        this.nome = nome;
        this.distrito = distrito;
        this.genero = genero;
        this.morada = morada;
        this.data = data;
        this.email = email;
        this.curso = curso;
    }
}

let aluno= {
    "nome": "",
    "distrito":"",
    "genero":"",
    "morada":"",
    "data":"",
    "email": "",
    "curso": ""
}

let arrAluno = [];
let cont = 0;

document.getElementById("inserirAluno").onclick = function () { insert_Aluno(); };
document.getElementById("eliminaAluno").onclick = function () { elimina_Aluno(); };
document.getElementById("atualiza").onclick = function () { muda_Aluno() };



function insert_Aluno() {
    cont++;

    //INPUTS
    let nome = document.getElementById("nomeAluno").value;
    let distrito = document.getElementById("distritoAluno").value;
    let genero = document.getElementById("generoAluno").value;
    let morada = document.getElementById("moradaAluno").value;
    let data = document.getElementById("dataAluno").value;
    let email = document.getElementById("emailAluno").value;
    let curso = document.getElementById("cursoAluno").value;

    let aluno = new Aluno(nome,distrito, genero, morada, data, email, curso)
    // CRIA ELEMENTOS DE FORMA DINAMICA!
    arrAluno.push(aluno);

    let element = document.createElement('tr');
    document.getElementById("mostrarAluno").appendChild(element);

    let numeroAluno = document.createElement('td');
    numeroAluno.innerHTML = cont;
    element.appendChild(numeroAluno);

    let nomeElement = document.createElement('td');
    nomeElement.innerHTML = aluno.nome;
    element.appendChild(nomeElement);

    let distritoElement = document.createElement('td');
    distritoElement.innerHTML = aluno.distrito;
    element.appendChild(distritoElement);

    let generoElement = document.createElement('td');
    generoElement.innerHTML = aluno.nome;
    element.appendChild(generoElement);

    let moradaElement = document.createElement('td');
    moradaElement.innerHTML = aluno.nome;
    element.appendChild(moradaElement);

    let dataElement = document.createElement('td');
    dataElement.innerHTML = aluno.nome;
    element.appendChild(dataElement);

    let emailElement = document.createElement('td');
    emailElement.innerHTML = aluno.email;
    element.appendChild(emailElement);

    let cursosElement = document.createElement('td');
    cursosElement.innerHTML = aluno.curso;
    element.appendChild(cursosElement);

}

function muda_Aluno() {

    let numeroAlunoMudar = document.getElementById("numeroAlunoMudar").value;

    let mudaNome = document.getElementById("mudaNome").value;
    let mudaDistrito = document.getElementById("mudaDistrito").value;
    let mudaGenero = document.getElementById("mudaGenero").value;
    let mudaMorada = document.getElementById("mudaMorada").value;
    let mudaData = document.getElementById("mudaData").value;
    let mudaEmail = document.getElementById("mudaEmail").value;
    let mudaCurso = document.getElementById("mudaCurso").value;

    console.log(numeroAlunoMudar, mudaNome);
    console.log(numeroAlunoMudar, mudaDistrito);
    console.log(numeroAlunoMudar, mudaGenero);
    console.log(numeroAlunoMudar, mudaMorada);
    console.log(numeroAlunoMudar, mudaData);
    console.log(numeroAlunoMudar, mudaEmail);
    console.log(numeroAlunoMudar, mudaCurso);

    arrAluno[numeroAlunoMudarr - 1].nome = mudaNome;    
    arrAluno[numeroAlunoMudar - 1].distrito = mudaDistrito;    
    arrAluno[numeroAlunoMudar - 1].genero = mudaGenero;
    arrAluno[numeroAlunoMudar - 1].morada = mudaMorada;
    arrAluno[numeroAlunoMudar - 1].data = mudaData;
    arrAluno[numeroAlunoMudar - 1].email = mudaEmail;
    arrAluno[numeroAlunoMudar - 1].idade = mudaCurso;


    console.log(arrAluno);
}

function elimina_Aluno() {

    let numeroAlunoEliminar = document.getElementById("numeroAlunoEliminar").value;

    arrAluno.splice(numeroAlunoEliminar - 1, 1)

    console.log(arrAluno);

    let AlunoEliminar = document.getElementById("mostrarAluno").childNodes[numeroAlunoEliminar];
    console.log(AlunoEliminar);
    document.getElementById("mostrarAluno").deleteRow(numeroAlunoEliminar);
    cont--;
    //Após apagar um número deve atualizar a página e voltar a escrever o array para assim ser mostrados os números corretamente.
}